/*
 * SPI_core.c
 *
 * Created: 12/4/2023 10:04:54 PM
 *  Author: eiadA
 */ 
