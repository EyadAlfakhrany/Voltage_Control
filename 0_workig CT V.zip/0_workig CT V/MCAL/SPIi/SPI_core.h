/*
 * SPI_core.h
 *
 * Created: 12/4/2023 10:05:12 PM
 *  Author: eiadA
 */ 


#ifndef SPI_CORE_H_
#define SPI_CORE_H_





#endif /* SPI_CORE_H_ */