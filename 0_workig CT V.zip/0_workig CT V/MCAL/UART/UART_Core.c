/*
 * UART_Core.c
 *
 * Created: 11/15/2023 8:38:40 PM
 * Author: EyadA
 */ 

/**********************************************************************************************************************
 *  INCLUDES
 *********************************************************************************************************************/
#include "UART_Core.h"

/**********************************************************************************************************************
*  LOCAL MACROS CONSTANT\FUNCTION
*********************************************************************************************************************/

/**********************************************************************************************************************
 *  LOCAL DATA 
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *  GLOBAL DATA
 *********************************************************************************************************************/
uint8	UART_TRANSMITE_DATA[TX_BUFFER_SIZE];
uint8	UART_RECEIVED_DATA[7];
uint8 TX_STATUS_FLAG = 0;
uint8 TX_Cnt = 0;
uint8 RX_STATUS_FLAG = 0;
/**********************************************************************************************************************
 *  LOCAL FUNCTION PROTOTYPES
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *  LOCAL FUNCTIONS
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *  GLOBAL FUNCTIONS
 *********************************************************************************************************************/


/******************************************************************************
* \Syntax          : Std_ReturnType FunctionName(AnyType parameterName)        
* \Description     : Describe this service                                    
*                                                                             
* \Sync\Async      : Synchronous                                               
* \Reentrancy      : Non Reentrant                                             
* \Parameters (in) : parameterName   Parameter Describtion                     
* \Parameters (out): None                                                      
* \Return value:   : Std_ReturnType  E_OK
*                                    E_NOT_OK                                  
*******************************************************************************/
void UART_Init(void)
{
	uint8 BaudRate_Value_l = 0;
	
	#if (UART_PARITY_STATE   ==   ENABLE)
	 #if (UART_PARITY_TYPE   ==    PARITY_ODD)
	  UCSRC |= 0XD0 ;
	 #elif(UART_PARITY_TYPE  ==    PARITY_EVEN)
	  UCSRC |= 0XA0;
	 #endif /*if (UART_PARITY_TYPE   ==    PARITY_ODD)*/
	#endif /*if (UART_PARITY_STATE   ==   ENABLE)*/
	
	#if (UART_DATA_BYTES    ==    UART_DATA_BYTES_5)
	 UCSRC |= 0X80;
	#elif (UART_DATA_BYTES    ==    UART_DATA_BYTES_6)
	 UCSRC |= 0X82;
	#elif (UART_DATA_BYTES    ==    UART_DATA_BYTES_7)
	 UCSRC |= 0X84;
	#elif (UART_DATA_BYTES    ==    UART_DATA_BYTES_8)
	 UCSRC |= 0X86;
	#endif /*if (UART_DATA_BYTES    ==    UART_DATA_BYTES_5)*/
	
	#if (UART_INTERRUPT_STATE ==  ENABLE)
	SET_BIT(UCSRB , 7); /*RX INT*/
	SET_BIT(UCSRB , 6); /*TX INT*/
	#elif (UART_INTERRUPT_STATE ==  DISABLE)
	CLR_BIT(UCSRB , 7); /*RX INT*/
	CLR_BIT(UCSRB , 6); /*TX INT*/	
	#endif /*if (UART_INTERRUPT_STATE ==  ENABLE)*/
	
	/*Enable TX*/
	SET_BIT(UCSRB , 3);
	/*Enable RX*/
	SET_BIT(UCSRB , 4);
	/*Baudrate Equation*/
	BaudRate_Value_l = ((160000U) / (UART_BAUD_RATE * 16)) - 1;
	UBRRL = BaudRate_Value_l;
}


void UART_InitTx(void)
{
	/*Enable TX INT*/
	SET_BIT(UCSRB , 6);
	TX_STATUS_FLAG = 1;
}

void UART_SendData(void)
{
	if(TX_Cnt == TX_BUFFER_SIZE)
	{
		TX_Cnt = 0;
		TX_STATUS_FLAG = 0;
		CLR_BIT(UCSRB , 6);
	}
	if(TX_STATUS_FLAG == 1)
	{
		UDR = UART_TRANSMITE_DATA[TX_Cnt];
		TX_STATUS_FLAG = 0;
	}
}


uint8 UART_RX_Status(void)
{
	uint8 Rec_Status = 0;
	
	if(RX_STATUS_FLAG == 1)
	{
		Rec_Status = 1;
		RX_STATUS_FLAG = 0;
	}
	
	return Rec_Status;
}


/**********************************************************************************************************************
 *  END OF FILE: FileName.c
 *********************************************************************************************************************/
